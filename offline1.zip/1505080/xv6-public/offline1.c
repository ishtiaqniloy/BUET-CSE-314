#include "types.h"
#include "user.h"

int main(int argc, char *argv[])
{
	int returnValue;
	returnValue = abdullah_ishtiaq();

	printf( 0, "%d\n", returnValue); 


	exit();

}